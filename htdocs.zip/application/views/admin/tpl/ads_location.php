               
<!-- Common -->
<header id="topbar" class="affix">
        <div class="topbar-left">
                <!-- Breadcrumbs -->
                <ol class="breadcrumb">
        <li class="crumb-icon">
                <a href="http://demothu.web5s.com.vn/admin.html" title="">
                        <span class="glyphicon glyphicon-home"></span>
                </a>
        </li>
        
                                <li >
                        <a href="http://demothu.web5s.com.vn/admin/ads_location.html">Vị trí</a>
                </li>
                        <li class="current">
                        <a href="">Danh sách</a>
                </li>
        </ol>        </div>
        <div class="topbar-right">
                        </div>
</header>

<!-- Message -->

<!-- Widget verify action -->
<div class="modal fade bs-example-modal-sm" tabindex="-1" role="dialog" aria-labelledby="mySmallModalLabel" id="box_verify_action">
  <div class="modal-dialog modal-sm">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
        <h4 class="modal-title"><i class="fa  fa-life-bouy"></i> Thông báo</h4>
      </div>
      <div class="modal-body">
            <p><i class="fa  fa-fa-warning"></i><span  id="notice"></span></p>
      </div>
      <div class="modal-footer">
        <a id="cancel" href="javascript:void(0)" class="btn btn-default" data-dismiss="modal">Hủy bỏ</a>
        <a id="accept" href="javascript:void(0)" class="btn btn-primary">Xác nhận</a>
      </div>
    </div>
  </div>
</div>
<!-- Main content wrapper -->
<section id="content">
	<div class="panel">
                <div class="panel-heading"> 
                        <ul class="tabs nav panel-tabs-border panel-tabs panel-tabs-left">
                                <li class="active"><a href="#banner_size">Danh sách</a></li>
                        </ul>
                </div>
		<div class="panel-body pn p10">
                        <table class="footable table table-striped table-hover table-bordered admin-form fs13">
			<thead>
				<tr class="info">
                                        <th class="footable-first-column w100" data-hide="phone">Thứ tự</th>
					<th class="text-left footable-first-column" data-toggle="true">Tên</th>
					<th data-hide="phone">Mã</th>
					<th class="w200" data-hide="phone">Kích thước banner (px)</th>
					<th class="w150" data-hide="phone">Số lượng banner</th>
					<th class="w150">Hành động</th>
				</tr>
			</thead>
			
			<tbody>
							<tr>
                                        <td class="text-center">1</td>
                                        
					<td>Banner dưới slider</td>
					
					<td class="text-center">top_home</td>
					
					<td class="text-center">
                                                                                               262x132px                                                                                         
                                        </td>
                                        
					<td class="text-center">10</td>
                                        
					<td class="text-center">
						<a href="http://demothu.web5s.com.vn/admin/ads_location/action/edit/1757.html" title="Chỉnh sửa" 
                                                   class="btn btn-xs btn-warning btn-edit br3"><i class="fa fa-pencil"></i></a>
                                                <a href="javascript:void(0)" _url="http://demothu.web5s.com.vn/admin/ads_location/action/del/1757.html" 
                                                   title="Xóa" class="btn btn-xs btn-danger btn-delete br3 verify_action"
                                                            notice="Bạn có chắc chắn muốn xóa vị trí đặt quảng cáo?"
                                                >
                                                    <i class="fa fa-times"></i>
                                                </a>
					</td>
				</tr>
							<tr>
                                        <td class="text-center">2</td>
                                        
					<td>Banner giữa trang chủ</td>
					
					<td class="text-center">main_home</td>
					
					<td class="text-center">
                                                                                               1170x0px                                                                                         
                                        </td>
                                        
					<td class="text-center">3</td>
                                        
					<td class="text-center">
						<a href="http://demothu.web5s.com.vn/admin/ads_location/action/edit/1758.html" title="Chỉnh sửa" 
                                                   class="btn btn-xs btn-warning btn-edit br3"><i class="fa fa-pencil"></i></a>
                                                <a href="javascript:void(0)" _url="http://demothu.web5s.com.vn/admin/ads_location/action/del/1758.html" 
                                                   title="Xóa" class="btn btn-xs btn-danger btn-delete br3 verify_action"
                                                            notice="Bạn có chắc chắn muốn xóa vị trí đặt quảng cáo?"
                                                >
                                                    <i class="fa fa-times"></i>
                                                </a>
					</td>
				</tr>
							<tr>
                                        <td class="text-center">3</td>
                                        
					<td>Banner đối tác</td>
					
					<td class="text-center">partner</td>
					
					<td class="text-center">
                                                                                               105x97px                                                                                         
                                        </td>
                                        
					<td class="text-center">20</td>
                                        
					<td class="text-center">
						<a href="http://demothu.web5s.com.vn/admin/ads_location/action/edit/1759.html" title="Chỉnh sửa" 
                                                   class="btn btn-xs btn-warning btn-edit br3"><i class="fa fa-pencil"></i></a>
                                                <a href="javascript:void(0)" _url="http://demothu.web5s.com.vn/admin/ads_location/action/del/1759.html" 
                                                   title="Xóa" class="btn btn-xs btn-danger btn-delete br3 verify_action"
                                                            notice="Bạn có chắc chắn muốn xóa vị trí đặt quảng cáo?"
                                                >
                                                    <i class="fa fa-times"></i>
                                                </a>
					</td>
				</tr>
							<tr>
                                        <td class="text-center">4</td>
                                        
					<td>Banner Sidebar</td>
					
					<td class="text-center">sidebar</td>
					
					<td class="text-center">
                                                                                               263x0px                                                                                         
                                        </td>
                                        
					<td class="text-center">4</td>
                                        
					<td class="text-center">
						<a href="http://demothu.web5s.com.vn/admin/ads_location/action/edit/1760.html" title="Chỉnh sửa" 
                                                   class="btn btn-xs btn-warning btn-edit br3"><i class="fa fa-pencil"></i></a>
                                                <a href="javascript:void(0)" _url="http://demothu.web5s.com.vn/admin/ads_location/action/del/1760.html" 
                                                   title="Xóa" class="btn btn-xs btn-danger btn-delete br3 verify_action"
                                                            notice="Bạn có chắc chắn muốn xóa vị trí đặt quảng cáo?"
                                                >
                                                    <i class="fa fa-times"></i>
                                                </a>
					</td>
				</tr>
						</tbody>
                    </table>
                </div>
        </div>
</section>
        
                <!-- Modal -->
                <div class="modal fade" id="modal" tabindex="-1" role="dialog">
                    <div class="modal-dialog" role="document">
                        <div class="modal_click_content"></div>
                    </div>
                </div>

