<?php 
    //$data_breadcrumb = breadcrumb($tpl);
 ?>
<ol class="breadcrumb">
    <li class="crumb-icon">
        <a href="" title="">
            <span class="glyphicon glyphicon-home"></span>
        </a>
    </li>
    
   <li>
       <a href="">Tài khoản</a>
   </li>
   <li>
       <a href="">Ban quản trị</a>
   </li>
   <li class="current">
       <a href="">Danh sách</a>
   </li>
</ol>