
    <div class="topbar-left">
        <!-- Breadcrumbs -->
        <?= $breadcrumbs; ?>
    </div>
    <div class="topbar-right">
        <a class="btn btn-success fw600 pull-right mr10 br3 pv5" href="http://demothu.web5s.com.vn/admin/admin/add.html">
            <i class="fa fa-plus mr5"></i> Thêm mới        </a>
    </div>