<div class="nano-content"> 
  <!-- sidebar menu -->
  <ul class="nav sidebar-menu">
    <!-- Label -->
    <li class="active"> <a class=" menu-open" href="http://localhost/admin/administrator/home">
    <span class="glyphicons glyphicons-home"></span> <span class="sidebar-title">Bảng điều khiển</span> </a> </li>
    <!-- Label -->
    <li class="sidebar-label pt15">Quản lý sản phẩm</li>
    <li class=""> </li>
    <li class=""><a class="accordion-toggle " href="http://localhost/admin/administrator/product">
    <span class="glyphicons glyphicons-product"></span><span class="sidebar-title">Sản phẩm</span><span class="caret"></span></a>
      <ul class="nav sub-nav">
        <li class=""><a href="http://localhost/admin/administrator/product" title="Danh sách sản phẩm">Danh sách sản phẩm</a></li>
        <li class=""><a href="http://localhost/admin/administrator/cat" title="Danh mục">Danh mục</a></li>
      </ul>
    </li>
    
    <!-- Label -->
    <li class=""> </li>
    <li class=""><a class="accordion-toggle " href="http://localhost/admin/administrator/tran">
    <span class="glyphicons glyphicons-tran"></span><span class="sidebar-title">Gian hàng</span><span class="caret"></span></a>
      <ul class="nav sub-nav">
        <li class=""><a href="http://localhost/admin/administrator/customer" title="Khách hàng">Khách hàng</a></li>
        <li class=""><a href="http://localhost/admin/administrator/tran" title="Đơn hàng ">Quản lý gian hàng </a></li>
        <li class=""><a href="http://localhost/admin/administrator/stats_product" title="Thống kê">Thêm gian hàng</a></li>
      </ul>
    </li>
    
    <!-- Label -->
    <li class="sidebar-label pt15">Quản lý nội dung</li>
    <li class=""> </li>
    <li class=""><a class="accordion-toggle " href="http://localhost/admin/administrator/news">
    <span class="glyphicons glyphicons-news"></span><span class="sidebar-title">Page</span><span class="caret"></span></a>
      <ul class="nav sub-nav">
        <li class=""><a href="http://localhost/admin/administrator/news" title="Quản lý tin tức">Quản lý viết</a></li>
        <li class=""><a href="http://localhost/admin/administrator/cat_news" title="Thể loại tin">Thêm bài viết</a></li>
      </ul>
    </li>
    
    <!-- Label -->
    <li class=""> </li>
    <li class=""><a class="accordion-toggle " href="http://localhost/admin/administrator/contact">
    <span class="glyphicons glyphicons-contact"></span><span class="sidebar-title">Khách hàng liên hệ</span><span class="caret"></span></a>
      <ul class="nav sub-nav">
        <li class=""><a href="http://localhost/admin/administrator/contact" title="Danh sách liên hệ">Danh sách liên hệ</a></li>
        <li class=""><a href="http://localhost/admin/administrator/send_email" title="Đăng ký nhận email">Đăng ký nhận email</a></li>
      </ul>
    </li>
    
    <!-- Label -->
    <li class="sidebar-label pt15">Cấu hình hệ thống</li>
    <li class=""> </li>
    <li class=""><a class="accordion-toggle " href="http://localhost/admin/administrator/user">
    <span class="glyphicons glyphicons-user"></span><span class="sidebar-title">Tài khoản</span><span class="caret"></span></a>
      <ul class="nav sub-nav">
        <li class=""><a href="http://localhost/admin/administrator/admin_group" title="Nhóm quản trị">Nhóm quản trị</a></li>
        <li class=""><a href="http://localhost/admin/administrator/listadmin" title="Ban quản trị">Ban quản trị</a></li>
        <li class=""><a href="http://localhost/admin/administrator/listuser" title="Thành viên">Thành viên</a></li>
      </ul>
    </li>
    
    <!-- Label -->
    <li class=""> </li>
    <li class=""><a class="accordion-toggle " href="http://localhost/admin/administrator/setting">
    <span class="glyphicons glyphicons-setting"></span><span class="sidebar-title">Cấu hình</span><span class="caret"></span></a>
      <ul class="nav sub-nav">
        <li class=""><a href="http://localhost/admin/administrator/data" title="Dữ liệu trang">Dữ liệu trang</a></li>
      </ul>
    </li>
    <!-- Resources stats -->
    <li class="sidebar-label pt25 pb10 text-info">Tài nguyên</li>
    <!-- Sidebar progress bars -->
    <li class="sidebar-stat mb10"> <a class="fs11"> <span class="fa fa-tags text-info"></span>
    <span class="sidebar-title text-info">Sản phẩm</span> <span class="pull-right mr20">8/30</span>
      <div class="progress progress-bar-xs ml20 mr20">
        <div class="progress-bar progress-bar-info" role="progressbar" aria-valuenow="45" aria-valuemin="0" aria-valuemax="26.666666666667" style="width: 26.666666666667%"> <span class="sr-only">26.666666666667%</span> </div>
      </div>
      </a> </li>
    <li class="sidebar-stat mb10"> <a class="fs11"> <span class="fa fa-hdd-o text-warning"></span>
    <span class="sidebar-title text-warning">Dung lượng</span> <span class="pull-right mr20">4/100Mb</span>
      <div class="progress progress-bar-xs ml20 mr20">
        <div class="progress-bar progress-bar-warning" role="progressbar" aria-valuenow="45" aria-valuemin="0" aria-valuemax="3.8203125" style="width: 3.8203125%"> <span class="sr-only">3.8203125%</span> </div>
      </div>
      </a> </li>
    <li class="sidebar-stat mb10"> <a class="fs11"><span class="fa fa-tachometer text-success"></span>
    <span class="sidebar-title text-success">Băng thông</span> <span class="pull-right mr20">Không giới hạn</span>
      <div class="progress progress-bar-xs ml20 mr20">
        <div class="progress-bar progress-bar-success" role="progressbar" aria-valuenow="45" aria-valuemin="0" aria-valuemax="100" style="width: 100%"> <span class="sr-only">100%</span> </div>
      </div>
      </a> </li>
  </ul>
</div>
