<!DOCTYPE html>
<html>
<head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <title>Shop BanHangGiaRe tại ChoDienTu.vn</title>
            <meta name="description" content="Shop BanHangGiaRe - 01234917936 tại ChoDienTu.vn">
            <meta property="og:type" content="website">
            <meta property="og:title" content="Shop BanHangGiaRe tại ChoDienTu.vn">
            <meta property="og:site_name" content="ChợĐiệnTử eBay Việt Nam">
            <meta property="og:url" content="https://www.chodientu.vn/shop/BanHangGiaRe">
            <meta property="og:image" content="">
            <meta property="og:description" content="Shop BanHangGiaRe - 01234917936 tại ChoDienTu.vn">
            
<script type="text/javascript" src="https://bam.nr-data.net/1/a8948bf81e?a=9036146&amp;v=952.3a19e93&amp;to=NF1TZ0RTDURRUERZDA0XYkNEWw1Qc1xeRBEMVF1WRB0QX19DH0sCD1FQQEsSS3B1Zxk%3D&amp;rst=2606&amp;ref=https://www.chodientu.vn/shop/BanHangGiaRe&amp;ap=512&amp;be=749&amp;fe=1224&amp;dc=440&amp;perf=%7B%22timing%22:%7B%22of%22:1466753486256,%22n%22:0,%22f%22:0,%22dn%22:9,%22dne%22:55,%22c%22:55,%22s%22:60,%22ce%22:96,%22rq%22:96,%22rp%22:625,%22rpe%22:628,%22dl%22:628,%22di%22:1187,%22ds%22:1187,%22de%22:1255,%22dc%22:1973,%22l%22:1973,%22le%22:1974%7D,%22navigation%22:%7B%7D%7D&amp;jsonp=NREUM.setToken"></script><script src="https://js-agent.newrelic.com/nr-952.min.js"></script><script type="text/javascript" async="" src="https://www.google-analytics.com/plugins/ua/linkid.js"></script><script async="" src="//www.google-analytics.com/analytics.js"></script><script async="" charset="utf-8" src="//v2.zopim.com/?Iv8sYsDQxsLzzOFZPCEAEceSUOiE63bg" type="text/javascript"></script><script type="text/javascript">window.NREUM||(NREUM={}),__nr_require=function(e,n,t){function r(t){if(!n[t]){var o=n[t]={exports:{}};e[t][0].call(o.exports,function(n){var o=e[t][1][n];return r(o||n)},o,o.exports)}return n[t].exports}if("function"==typeof __nr_require)return __nr_require;for(var o=0;o<t.length;o++)r(t[o]);return r}({1:[function(e,n,t){function r(e,n){return function(){o(e,[(new Date).getTime()].concat(a(arguments)),null,n)}}var o=e("handle"),i=e(2),a=e(3);"undefined"==typeof window.newrelic&&(newrelic=NREUM);var c=["setPageViewName","setCustomAttribute","finished","addToTrace","inlineHit"],u=["addPageAction"],f="api-";i(c,function(e,n){newrelic[n]=r(f+n,"api")}),i(u,function(e,n){newrelic[n]=r(f+n)}),n.exports=newrelic,newrelic.noticeError=function(e){"string"==typeof e&&(e=new Error(e)),o("err",[e,(new Date).getTime()])}},{}],2:[function(e,n,t){function r(e,n){var t=[],r="",i=0;for(r in e)o.call(e,r)&&(t[i]=n(r,e[r]),i+=1);return t}var o=Object.prototype.hasOwnProperty;n.exports=r},{}],3:[function(e,n,t){function r(e,n,t){n||(n=0),"undefined"==typeof t&&(t=e?e.length:0);for(var r=-1,o=t-n||0,i=Array(0>o?0:o);++r<o;)i[r]=e[n+r];return i}n.exports=r},{}],ee:[function(e,n,t){function r(){}function o(e){function n(e){return e&&e instanceof r?e:e?c(e,a,i):i()}function t(t,r,o){e&&e(t,r,o);for(var i=n(o),a=l(t),c=a.length,u=0;c>u;u++)a[u].apply(i,r);var s=f[m[t]];return s&&s.push([w,t,r,i]),i}function p(e,n){g[e]=l(e).concat(n)}function l(e){return g[e]||[]}function d(e){return s[e]=s[e]||o(t)}function v(e,n){u(e,function(e,t){n=n||"feature",m[t]=n,n in f||(f[n]=[])})}var g={},m={},w={on:p,emit:t,get:d,listeners:l,context:n,buffer:v};return w}function i(){return new r}var a="nr@context",c=e("gos"),u=e(2),f={},s={},p=n.exports=o();p.backlog=f},{}],gos:[function(e,n,t){function r(e,n,t){if(o.call(e,n))return e[n];var r=t();if(Object.defineProperty&&Object.keys)try{return Object.defineProperty(e,n,{value:r,writable:!0,enumerable:!1}),r}catch(i){}return e[n]=r,r}var o=Object.prototype.hasOwnProperty;n.exports=r},{}],handle:[function(e,n,t){function r(e,n,t,r){o.buffer([e],r),o.emit(e,n,t)}var o=e("ee").get("handle");n.exports=r,r.ee=o},{}],id:[function(e,n,t){function r(e){var n=typeof e;return!e||"object"!==n&&"function"!==n?-1:e===window?0:a(e,i,function(){return o++})}var o=1,i="nr@id",a=e("gos");n.exports=r},{}],loader:[function(e,n,t){function r(){if(!b++){var e=y.info=NREUM.info,n=s.getElementsByTagName("script")[0];if(e&&e.licenseKey&&e.applicationID&&n){u(m,function(n,t){e[n]||(e[n]=t)});var t="https"===g.split(":")[0]||e.sslForHttp;y.proto=t?"https://":"http://",c("mark",["onload",a()],null,"api");var r=s.createElement("script");r.src=y.proto+e.agent,n.parentNode.insertBefore(r,n)}}}function o(){"complete"===s.readyState&&i()}function i(){c("mark",["domContent",a()],null,"api")}function a(){return(new Date).getTime()}var c=e("handle"),u=e(2),f=window,s=f.document,p="addEventListener",l="attachEvent",d=f.XMLHttpRequest,v=d&&d.prototype;NREUM.o={ST:setTimeout,CT:clearTimeout,XHR:d,REQ:f.Request,EV:f.Event,PR:f.Promise,MO:f.MutationObserver},e(1);var g=""+location,m={beacon:"bam.nr-data.net",errorBeacon:"bam.nr-data.net",agent:"js-agent.newrelic.com/nr-952.min.js"},w=d&&v&&v[p]&&!/CriOS/.test(navigator.userAgent),y=n.exports={offset:a(),origin:g,features:{},xhrWrappable:w};s[p]?(s[p]("DOMContentLoaded",i,!1),f[p]("load",r,!1)):(s[l]("onreadystatechange",o),f[l]("onload",r)),c("mark",["firstbyte",a()],null,"api");var b=0},{}]},{},["loader"]);</script><link rel="canonical" href="https://www.chodientu.vn/shop/BanHangGiaRe">
        <meta property="fb:app_id" content="1647876942090395">
        <meta property="article:author" content="https://www.facebook.com/chodientu">
        <meta name="p:domain_verify" content="c0477385dc0151259137b8df5c791bca">
        <meta name="globalsign-domain-verification" content="fH0v8d54j8aRLxlJ9jeIrkBvotYXdqHXkYKOkl7oif">
        <meta name="msvalidate.01" content="FABB65328FF4CB74888BAD4B38C988BC">
        <meta name="google-site-verification" content="Rs7bVnIWlZtf7OG5HUuuGgXEUV_Vaep9RGgE-C92Eg8">
        <link rel="shortcut icon" href="https://www.chodientu.vn/static/images/favicon.ico">

        <link rel="stylesheet" type="text/css" media="screen" href="https://www.chodientu.vn/jawr/gzip_N164807142/css/shopv2.css">
<script type="text/javascript" src="https://www.chodientu.vn/jawr/gzip_686242207/js/shopv2.js"></script><style>.cke{visibility:hidden;}</style>
<title>ChợĐiệnTử.vn - Shop Home</title>
        <script type="text/javascript">
            window.$zopim || (function (d, s) {
                var z = $zopim = function (c) {
                    z._.push(c)
                }, $ = z.s =
                        d.createElement(s), e = d.getElementsByTagName(s)[0];
                z.set = function (o) {
                    z.set.
                            _.push(o)
                };
                z._ = [];
                z.set._ = [];
                $.async = !0;
                $.setAttribute("charset", "utf-8");
                $.src = "//v2.zopim.com/?Iv8sYsDQxsLzzOFZPCEAEceSUOiE63bg";
                z.t = +new Date;
                $.
                        type = "text/javascript";
                e.parentNode.insertBefore($, e)
            })(document, "script");
        </script>
        <!--End of Zopim Live Chat Script-->
        <script>
            (function (i, s, o, g, r, a, m) {
                i['GoogleAnalyticsObject'] = r;
                i[r] = i[r] || function () {

                    (i[r].q = i[r].q || []).push(arguments)
                }, i[r].l = 1 * new Date();
                a = s.createElement(o),
                        m = s.getElementsByTagName(o)[0];
                a.async = 1;
                a.src = g;
                m.parentNode.insertBefore(a, m)
            })(window, document, 'script', '//www.google-analytics.com/analytics.js', 'ga');
            ga('create', 'UA-50752946-1', 'auto');
            ga('send', 'pageview');
            ga('require', 'linkid', 'linkid.js');   // gọi plug-in link attribution - xử lý pageview trùng link.
        </script>
    <style media="print" class="jx_ui_StyleSheet" __jx__id="___$_2" type="text/css">.zopim { display: none !important }</style></head>
<body style="padding-top: 35px;"><div class="zopim" __jx__id="___$_11 ___$_11" style="margin-top: 0px; margin-right: 0px; margin-bottom: 0px; padding: 0px; border: 0px; overflow: hidden; position: fixed; z-index: 16000002; width: 230px; height: 30px; right: 10px; bottom: 0px; background: transparent;"><iframe frameborder="0" src="about:blank" style="vertical-align: text-bottom; position: relative; width: 100%; height: 100%; min-width: 100%; min-height: 100%; max-width: 100%; max-height: 100%; margin: 0px; overflow: hidden; display: block; background-color: transparent;"></iframe></div><div class="zopim" __jx__id="___$_4 ___$_4" style="margin-top: 0px; margin-right: 0px; margin-bottom: 0px; padding: 0px; border: 0px; overflow: hidden; position: fixed; z-index: 16000001; right: 10px; bottom: 0px; border-top-left-radius: 5px; border-top-right-radius: 5px; display: none; box-shadow: rgba(0, 0, 0, 0.0980392) 0px 0px 3px 2px; background: transparent;"><iframe frameborder="0" src="about:blank" style="vertical-align: text-bottom; position: relative; width: 100%; height: 100%; min-width: 100%; min-height: 100%; max-width: 100%; max-height: 100%; margin: 0px; overflow: hidden; display: block; background-color: transparent;"></iframe></div>
        <div class="navigator">
    <div class="header-top header-fixed">
    	<div class="container">
        	<div class="ht-left">
            	<a href="https://www.chodientu.vn"><img src="https://www.chodientu.vn/static/shopv2/images/logo/logo-shop.png"></a>
            </div><!-- ht-left -->
            <div class="ht-right">
            	<ul>
                    <li class="popout-hoverjs">
                        <div class="ba-nolink">
                            <span class="ba-textsmall">Đăng nhập/Đăng ký</span>
                            </div>
                        <div class="popout-submenu popout-right">
                            <div class="ps-inner">
                                <i class="fa fa-caret-up"></i>
                                <div class="ps-padding">
                                    <ul class="ps-list ps-listicon">
                                            <li><p><a class="btn btn-danger btn-block" href="https://www.chodientu.vn/user/signin.html">ĐĂNG NHẬP HỆ THỐNG</a></p></li>
                                            <li><p class="btn-p">Bạn chưa có tài khoản? <a href="https://www.chodientu.vn/user/signup.html">Đăng ký ngay</a></p></li>
                                        </ul>
                                        <ul class="ps-list ps-listicon ps-lock">
                                            <li><a href="https://www.chodientu.vn/userv2/profile.html"><i class="fa fa-user"></i>Thông tin cá nhân</a></li>
                                            <li><a href="https://www.chodientu.vn/userv2/tai-khoan-xeng.html" class="icon-money"><i class="fa fa-money"></i>Xèng của bạn: </a></li>
                                            </ul>
                                            <div class="ps-line"></div>
                                            <ul class="ps-list ps-listicon ps-lock">
                                                <li><a href="https://www.chodientu.vn/userv2/order/buyer.html"><i class="fa fa-file-text"></i>Đơn hàng của tôi</a></li>
                                            <!--<li><a href="{baseUrl}/user/theo-doi-dau-gia.html"><i class="fa fa-archive"></i>Sản phẩm đang theo dõi</a></li>-->
                                        </ul>
                                        <div class="ps-line"></div>
                                        <ul class="ps-list ps-listicon ps-lock">
                                            <li><a href="https://www.chodientu.vn/userv2/dang-ban.html"><i class="fa fa-plus-circle"></i>Đăng bán</a></li>
                                            <li><a href="https://www.chodientu.vn/userv2/item.html"><i class="fa fa-th"></i>Danh sách sản phẩm</a></li>
                                            <li><a href="https://www.chodientu.vn/userv2/order/seller.html"><i class="fa fa-files-o"></i>Hoá đơn bán hàng</a></li>
                                            <li><a href="https://www.chodientu.vn/userv2/vipitem.html"><i class="fa fa-magic"></i>Quản lý tin VIP</a></li>
                                            <li><a href="https://www.chodientu.vn/userv2/posting.html"><i class="fa fa-cloud-upload"></i>Quản lý UP Tin</a></li>
                                            <li><a href="https://www.chodientu.vn/userv2/cau-hinh-shop.html"><i class="fa fa-cube"></i>Quản trị SHOP</a></li>
                                        </ul>
                                    </div><!-- ps-padding -->
                                </div><!-- ps-inner -->
                        </div><!-- popout-submenu -->
                    </li>
                    <li class="active">
                        <a href="javascript:void(0);" class="popout-hovercartjs" onclick="order.getcart();"><i class="fa fa-shopping-cart"></i><span class="badge cart-number"></span></a>
                    </li> 
                </ul>
            </div><!-- ht-right -->
        </div><!-- container -->
    </div><!-- header-top --> 
<div class="shop2-header">
    <div class="container">
        <div class="left">
            <!--<div class="wishlist"><a href="#"><i class="fa fa-heart"></i> Yêu thích (7)</a></div>-->
            <div class="hotline">Hotline: <b>01234917936</b></div>
        </div>
        <div class="mid">
            <div class="shop-name" id="shop-name"><h1>BanHangGiaRe</h1></div>
            <div class="shop-slogan" style="line-height: 24px; font-style: italic; display: block"></div>
        </div>
        <div class="right">
            <div class="search">
                Tìm kiếm sản phẩm
                <span class="search-btn"><i class="search-icon"></i></span>
            </div>
            <div class="search-input" style="display: none;">
                <div class="input-group">
                    <input type="text" name="txtSearch" class="form-control" placeholder="Tìm kiếm, Ví dụ: đầm dự tiệc, iphone 6, ipad">
                    <input type="hidden" name="url" value="https://www.chodientu.vn/shop/BanHangGiaRe">
                    <span class="input-group-btn">
                        <button class="btn btn-default" name="btnSearch" type="button"><span class="glyphicon glyphicon-search" aria-hidden="true"></span></button>
                    </span>
                </div><!-- /input-group -->
            </div>
        </div>
    </div>
</div>
<div class="shop2-nav">
    <div class="container">
        <ul>
            <li>
                <a href="https://www.chodientu.vn/shop/BanHangGiaRe">
                    <i class="nav-ico home"></i>
                    <span>Trang chủ</span>
                </a>
            </li>
            <li>
                <a href="https://www.chodientu.vn/shop/BanHangGiaRe/browse">
                    <i class="nav-ico product"></i>
                    <span>Sản phẩm</span>
                </a>
            </li>
            <li>
                <a href="https://www.chodientu.vn/shop/BanHangGiaRe/tin-tuc">
                    <i class="nav-ico news"></i>
                    <span>Tin tức</span>
                </a>
            </li>
            <li>
                <a href="https://www.chodientu.vn/shop/BanHangGiaRe/khuyen-mai">
                    <i class="nav-ico deal"></i>
                    <span>Khuyến mãi</span>
                </a>
            </li>
            <li>
                <a href="https://www.chodientu.vn/shop/BanHangGiaRe/lien-he">
                    <i class="nav-ico contact"></i>
                    <span>Liên hệ</span>
                </a>
            </li>
        </ul>
    </div>
</div>
</div><!-- navigator --><div class="container">
            <div class="shop2-content">
    <div class="row">
        <div class="col-md-9 pd-box">
            <div class="tabs">
                <ul class="nav nav-tabs" role="tablist">
                    <li role="presentation" class="active"><a href="#tab-1" aria-controls="home" role="tab" data-toggle="tab" aria-expanded="true">Hàng mới về</a></li>
                    <li role="presentation" class=""><a href="#tab-2" aria-controls="profile" role="tab" data-toggle="tab" aria-expanded="false">Nhiều lượt mua</a></li>
                </ul>
            </div>
            <div class="pd-list">
                <div class="tab-content">
                    <div role="tabpanel" class="tab-pane active" id="tab-1">
                        <ul>
                                <li>
                                        <div class="thumb">
                                            <span class="img"><img class="lazy" src="https://chodientu.r.worldssl.net/images/2016/06/19/item/10/49/6/thumb_1466333289109.jpeg" alt="" title=""></span>
                                            <div class="btn-box">
                                                <a href="https://www.chodientu.vn/loa-mini/loa-bluetooth-bose-mini-818507813426" class="btn btn-default view">Xem chi tiết</a>
                                                <!--<button type="button" onclick="order.buyNow('{item.id}');" class="btn btn-default cart">Thêm vào giỏ hàng</button>-->
                                            </div>
                                            <!--<span class="new-tag">New</span>-->
                                            <!--<span class="hot-tag">Hot</span>-->
                                            <!--<span class="love-tag"><i name="cateItem" class="fa"></i></span>-->
                                        </div>
                                        <div class="info">
                                            <a href="https://www.chodientu.vn/loa-mini/loa-bluetooth-bose-mini-818507813426" class="name">LOA BLUETOOTH BOSE MINI</a>
                                            <div class="price-rate">
                                                <div class="price">
                                                    <span>225.000đ</span>
                                                    <span class="old-price">350.000đ</span>
                                                    </div>
                                            </div>
                                        </div>
                                    </li>
                                <li>
                                        <div class="thumb">
                                            <span class="img"><img class="lazy" src="https://chodientu.r.worldssl.net/images/2016/06/19/item/12/12/7/thumb_2166714_f0ef09150f9c95e0fbaced8296d150e8.jpg" alt="" title=""></span>
                                            <div class="btn-box">
                                                <a href="https://www.chodientu.vn/dien-thoai-di-dong/dien-thoai-nokia-6300-gold-705095573462" class="btn btn-default view">Xem chi tiết</a>
                                                <!--<button type="button" onclick="order.buyNow('{item.id}');" class="btn btn-default cart">Thêm vào giỏ hàng</button>-->
                                            </div>
                                            <!--<span class="new-tag">New</span>-->
                                            <!--<span class="hot-tag">Hot</span>-->
                                            <!--<span class="love-tag"><i name="cateItem" class="fa"></i></span>-->
                                        </div>
                                        <div class="info">
                                            <a href="https://www.chodientu.vn/dien-thoai-di-dong/dien-thoai-nokia-6300-gold-705095573462" class="name">Điện thoại nokia 6300 gold</a>
                                            <div class="price-rate">
                                                <div class="price">
                                                    <span>415.000đ</span>
                                                    <span class="old-price">570.000đ</span>
                                                    </div>
                                            </div>
                                        </div>
                                    </li>
                                <li>
                                        <div class="thumb">
                                            <span class="img"><img class="lazy" src="https://chodientu.r.worldssl.net/images/2016/06/19/item/10/54/7/thumb_1466333591679.jpeg" alt="" title=""></span>
                                            <div class="btn-box">
                                                <a href="https://www.chodientu.vn/loa-mini/loa-bluetooth-the-nho-wster-ws-136-478829594963" class="btn btn-default view">Xem chi tiết</a>
                                                <!--<button type="button" onclick="order.buyNow('{item.id}');" class="btn btn-default cart">Thêm vào giỏ hàng</button>-->
                                            </div>
                                            <!--<span class="new-tag">New</span>-->
                                            <!--<span class="hot-tag">Hot</span>-->
                                            <!--<span class="love-tag"><i name="cateItem" class="fa"></i></span>-->
                                        </div>
                                        <div class="info">
                                            <a href="https://www.chodientu.vn/loa-mini/loa-bluetooth-the-nho-wster-ws-136-478829594963" class="name">Loa bluetooth-Thẻ nhớ  WSTER WS-136</a>
                                            <div class="price-rate">
                                                <div class="price">
                                                    <span>220.000đ</span>
                                                    <span class="old-price">350.000đ</span>
                                                    </div>
                                            </div>
                                        </div>
                                    </li>
                                <li>
                                        <div class="thumb">
                                            <span class="img"><img class="lazy" src="https://chodientu.r.worldssl.net/images/2016/06/19/item/11/04/5/thumb_1466334179914.jpeg" alt="" title=""></span>
                                            <div class="btn-box">
                                                <a href="https://www.chodientu.vn/do-choi-tri-tue-lap-ghep-mo-hinh/may-bay-dieu-khien-3-5-kenh-ls-222-346734953685" class="btn btn-default view">Xem chi tiết</a>
                                                <!--<button type="button" onclick="order.buyNow('{item.id}');" class="btn btn-default cart">Thêm vào giỏ hàng</button>-->
                                            </div>
                                            <!--<span class="new-tag">New</span>-->
                                            <!--<span class="hot-tag">Hot</span>-->
                                            <!--<span class="love-tag"><i name="cateItem" class="fa"></i></span>-->
                                        </div>
                                        <div class="info">
                                            <a href="https://www.chodientu.vn/do-choi-tri-tue-lap-ghep-mo-hinh/may-bay-dieu-khien-3-5-kenh-ls-222-346734953685" class="name">MÁY BAY ĐIỀU KHIỂN 3.5 KÊNH LS-222</a>
                                            <div class="price-rate">
                                                <div class="price">
                                                    <span>350.000đ</span>
                                                    <span class="old-price">450.000đ</span>
                                                    </div>
                                            </div>
                                        </div>
                                    </li>
                                <li>
                                        <div class="thumb">
                                            <span class="img"><img class="lazy" src="https://chodientu.r.worldssl.net/images/2016/06/19/item/10/38/2/thumb_1466332601971.jpeg" alt="" title=""></span>
                                            <div class="btn-box">
                                                <a href="https://www.chodientu.vn/dong-ho-deo-tay-nam/dong-ho-thong-minh-dz09-993908613861" class="btn btn-default view">Xem chi tiết</a>
                                                <!--<button type="button" onclick="order.buyNow('{item.id}');" class="btn btn-default cart">Thêm vào giỏ hàng</button>-->
                                            </div>
                                            <!--<span class="new-tag">New</span>-->
                                            <!--<span class="hot-tag">Hot</span>-->
                                            <!--<span class="love-tag"><i name="cateItem" class="fa"></i></span>-->
                                        </div>
                                        <div class="info">
                                            <a href="https://www.chodientu.vn/dong-ho-deo-tay-nam/dong-ho-thong-minh-dz09-993908613861" class="name">Đồng hồ thông minh DZ09</a>
                                            <div class="price-rate">
                                                <div class="price">
                                                    <span>345.000đ</span>
                                                    <span class="old-price">450.000đ</span>
                                                    </div>
                                            </div>
                                        </div>
                                    </li>
                                </ul>
                            <div class="seeall-box">
                                <button type="button" onclick="shopv2.linkBrowses('BanHangGiaRe');" class="btn btn-default">Xem tất cả sản phẩm</button>
                            </div>
                        </div>
                    <div role="tabpanel" class="tab-pane" id="tab-2">
                        <ul>
                                <li>
                                        <div class="thumb">
                                            <span class="img"><img class="lazy" src="https://chodientu.r.worldssl.net/images/2016/06/19/item/12/12/7/thumb_2166714_f0ef09150f9c95e0fbaced8296d150e8.jpg" alt="" title=""></span>
                                            <div class="btn-box">
                                                <a href="https://www.chodientu.vn/dien-thoai-di-dong/dien-thoai-nokia-6300-gold-705095573462" class="btn btn-default view">Xem chi tiết</a>
                                                <!--<button type="button" onclick="order.buyNow('{item.id}');" class="btn btn-default cart">Thêm vào giỏ hàng</button>-->
                                            </div>
                                            <!--<span class="new-tag">New</span>-->
                                            <!--<span class="hot-tag">Hot</span>-->
                                            <!--<span class="love-tag"><i name="cateItem" class="fa"></i></span>-->
                                        </div>
                                        <div class="info">
                                            <a href="https://www.chodientu.vn/dien-thoai-di-dong/dien-thoai-nokia-6300-gold-705095573462" class="name">Điện thoại nokia 6300 gold</a>
                                            <div class="price-rate">
                                                <div class="price">
                                                    <span>415.000đ</span>
                                                    <span class="old-price">570.000đ</span>
                                                    </div>
                                            </div>
                                        </div>
                                    </li>
                                <li>
                                        <div class="thumb">
                                            <span class="img"><img class="lazy" src="https://chodientu.r.worldssl.net/images/2016/06/19/item/11/04/5/thumb_1466334179914.jpeg" alt="" title=""></span>
                                            <div class="btn-box">
                                                <a href="https://www.chodientu.vn/do-choi-tri-tue-lap-ghep-mo-hinh/may-bay-dieu-khien-3-5-kenh-ls-222-346734953685" class="btn btn-default view">Xem chi tiết</a>
                                                <!--<button type="button" onclick="order.buyNow('{item.id}');" class="btn btn-default cart">Thêm vào giỏ hàng</button>-->
                                            </div>
                                            <!--<span class="new-tag">New</span>-->
                                            <!--<span class="hot-tag">Hot</span>-->
                                            <!--<span class="love-tag"><i name="cateItem" class="fa"></i></span>-->
                                        </div>
                                        <div class="info">
                                            <a href="https://www.chodientu.vn/do-choi-tri-tue-lap-ghep-mo-hinh/may-bay-dieu-khien-3-5-kenh-ls-222-346734953685" class="name">MÁY BAY ĐIỀU KHIỂN 3.5 KÊNH LS-222</a>
                                            <div class="price-rate">
                                                <div class="price">
                                                    <span>350.000đ</span>
                                                    <span class="old-price">450.000đ</span>
                                                    </div>
                                            </div>
                                        </div>
                                    </li>
                                <li>
                                        <div class="thumb">
                                            <span class="img"><img class="lazy" src="https://chodientu.r.worldssl.net/images/2016/06/19/item/10/54/7/thumb_1466333591679.jpeg" alt="" title=""></span>
                                            <div class="btn-box">
                                                <a href="https://www.chodientu.vn/loa-mini/loa-bluetooth-the-nho-wster-ws-136-478829594963" class="btn btn-default view">Xem chi tiết</a>
                                                <!--<button type="button" onclick="order.buyNow('{item.id}');" class="btn btn-default cart">Thêm vào giỏ hàng</button>-->
                                            </div>
                                            <!--<span class="new-tag">New</span>-->
                                            <!--<span class="hot-tag">Hot</span>-->
                                            <!--<span class="love-tag"><i name="cateItem" class="fa"></i></span>-->
                                        </div>
                                        <div class="info">
                                            <a href="https://www.chodientu.vn/loa-mini/loa-bluetooth-the-nho-wster-ws-136-478829594963" class="name">Loa bluetooth-Thẻ nhớ  WSTER WS-136</a>
                                            <div class="price-rate">
                                                <div class="price">
                                                    <span>220.000đ</span>
                                                    <span class="old-price">350.000đ</span>
                                                    </div>
                                            </div>
                                        </div>
                                    </li>
                                <li>
                                        <div class="thumb">
                                            <span class="img"><img class="lazy" src="https://chodientu.r.worldssl.net/images/2016/06/19/item/10/49/6/thumb_1466333289109.jpeg" alt="" title=""></span>
                                            <div class="btn-box">
                                                <a href="https://www.chodientu.vn/loa-mini/loa-bluetooth-bose-mini-818507813426" class="btn btn-default view">Xem chi tiết</a>
                                                <!--<button type="button" onclick="order.buyNow('{item.id}');" class="btn btn-default cart">Thêm vào giỏ hàng</button>-->
                                            </div>
                                            <!--<span class="new-tag">New</span>-->
                                            <!--<span class="hot-tag">Hot</span>-->
                                            <!--<span class="love-tag"><i name="cateItem" class="fa"></i></span>-->
                                        </div>
                                        <div class="info">
                                            <a href="https://www.chodientu.vn/loa-mini/loa-bluetooth-bose-mini-818507813426" class="name">LOA BLUETOOTH BOSE MINI</a>
                                            <div class="price-rate">
                                                <div class="price">
                                                    <span>225.000đ</span>
                                                    <span class="old-price">350.000đ</span>
                                                    </div>
                                            </div>
                                        </div>
                                    </li>
                                <li>
                                        <div class="thumb">
                                            <span class="img"><img class="lazy" src="https://chodientu.r.worldssl.net/images/2016/06/19/item/10/38/2/thumb_1466332601971.jpeg" alt="" title=""></span>
                                            <div class="btn-box">
                                                <a href="https://www.chodientu.vn/dong-ho-deo-tay-nam/dong-ho-thong-minh-dz09-993908613861" class="btn btn-default view">Xem chi tiết</a>
                                                <!--<button type="button" onclick="order.buyNow('{item.id}');" class="btn btn-default cart">Thêm vào giỏ hàng</button>-->
                                            </div>
                                            <!--<span class="new-tag">New</span>-->
                                            <!--<span class="hot-tag">Hot</span>-->
                                            <!--<span class="love-tag"><i name="cateItem" class="fa"></i></span>-->
                                        </div>
                                        <div class="info">
                                            <a href="https://www.chodientu.vn/dong-ho-deo-tay-nam/dong-ho-thong-minh-dz09-993908613861" class="name">Đồng hồ thông minh DZ09</a>
                                            <div class="price-rate">
                                                <div class="price">
                                                    <span>345.000đ</span>
                                                    <span class="old-price">450.000đ</span>
                                                    </div>
                                            </div>
                                        </div>
                                    </li>
                                </ul>
                        </div>
                </div>
            </div>
            </div><div class="col-md-3 side-bar">
    <div class="sidebar-box">
        <div class="title">Danh mục sản phẩm</div>
        <div class="panel-group" role="tablist" aria-multiselectable="true">
            <div class="panel panel-default">  <div class="panel-heading" role="tab" id="headingOne">    <h4 class="panel-title"> <a href="https://www.chodientu.vn/shop/BanHangGiaRe/dien-thoai-di-dong">Điện thoại di động</a> <a role="button" data-toggle="collapse" data-parent="#accordion" href="#collapseOne" aria-expanded="true" aria-controls="collapseOne"> </a></h4> </div></div><div class="panel panel-default">  <div class="panel-heading" role="tab" id="headingOne">    <h4 class="panel-title"> <a href="https://www.chodientu.vn/shop/BanHangGiaRe/loa-mini">Loa mini</a> <a role="button" data-toggle="collapse" data-parent="#accordion" href="#collapseOne" aria-expanded="true" aria-controls="collapseOne"> </a></h4> </div></div><div class="panel panel-default">  <div class="panel-heading" role="tab" id="headingOne">    <h4 class="panel-title"> <a href="https://www.chodientu.vn/shop/BanHangGiaRe/do-choi-tri-tue-lap-ghep-mo-hinh">Đồ chơi trí tuệ, lắp ghép, mô hình</a> <a role="button" data-toggle="collapse" data-parent="#accordion" href="#collapseOne" aria-expanded="true" aria-controls="collapseOne"> </a></h4> </div></div><div class="panel panel-default">  <div class="panel-heading" role="tab" id="headingOne">    <h4 class="panel-title"> <a href="https://www.chodientu.vn/shop/BanHangGiaRe/dong-ho-deo-tay-nam">Đồng hồ đeo tay nam</a> <a role="button" data-toggle="collapse" data-parent="#accordion" href="#collapseOne" aria-expanded="true" aria-controls="collapseOne"> </a></h4> </div></div></div>
    </div>
    
    <div class="sidebar-box viewed">
        <div class="title">
            <div class="left">Sản phẩm vừa xem</div>
            <div class="right">
                <div class="btn-group btn-group-sm" role="group" aria-label="...">
                    <button type="button" class="btn btn-default prev"><i class="fa fa-chevron-left"></i></button>
                    <button type="button" class="btn btn-default next"><i class="fa fa-chevron-right"></i></button>
                </div>
            </div>
        </div>
        <div class="sidebar-slider">
            <div id="shop2-viewed" class="owl-carousel owl-theme owl-loaded">
                
                
                
                
                
                <div class="owl-stage-outer"><div class="owl-stage" style="transform: translate3d(-1728px, 0px, 0px); transition: 0.25s; width: 2592px;"><div class="owl-item cloned" style="width: 288px; margin-right: 0px;"><div class="item">
                        <div class="thumb">
                            <a href="https://www.chodientu.vn/loa-mini/loa-bluetooth-bose-mini-818507813426">
                                <img style="width: 258px; height: 258px" src="https://chodientu.r.worldssl.net/images/2016/06/19/item/10/49/6/thumb_1466333289109.jpeg" alt="" title="">
                            </a>
                            <span class="sale-tag">36%<br>
                                    <i>Off</i>
                                </span>
                            </div>
                        <div class="info">
                            <a href="https://www.chodientu.vn/loa-mini/loa-bluetooth-bose-mini-818507813426" class="name">LOA BLUETOOTH BOSE MINI</a>
                            <div class="price">
                                <span>225.000đ</span>
                                <span class="old-price">350.000đ</span>
                                </div>
                        </div>
                    </div></div><div class="owl-item cloned" style="width: 288px; margin-right: 0px;"><div class="item">
                        <div class="thumb">
                            <a href="https://www.chodientu.vn/son-moi-618374322854/son-bbia-last-lipstick-vo-xanh-862262996269">
                                <img style="width: 258px; height: 258px" src="https://chodientu.r.worldssl.net/images/2016/06/23/item/04/35/3/thumb_son-li-bbia-last-lipstick-vo-xanh-1m4G3-04381f_simg_422f2e_1079-1079-0-0_cropf.jpg" alt="" title="">
                            </a>
                            <span class="sale-tag">46%<br>
                                    <i>Off</i>
                                </span>
                            </div>
                        <div class="info">
                            <a href="https://www.chodientu.vn/son-moi-618374322854/son-bbia-last-lipstick-vo-xanh-862262996269" class="name">Son BBIA Last Lipstick vỏ xanh</a>
                            <div class="price">
                                <span>90.000đ</span>
                                <span class="old-price">165.000đ</span>
                                </div>
                        </div>
                    </div></div><div class="owl-item" style="width: 288px; margin-right: 0px;"><div class="item">
                        <div class="thumb">
                            <a href="https://www.chodientu.vn/dien-thoai-di-dong/kinh-thuc-te-ao-3d-dung-cho-dien-thoai-vr-box-phien-ban-3-huong-hieu-hong-kong-electronics-170149032929">
                                <img style="width: 258px; height: 258px" src="https://chodientu.r.worldssl.net/images/2016/06/22/item/05/11/9/thumb_HTB1yW_1JVXXXXaQXXXXq6xXFXXX8_281_29.jpg" alt="" title="">
                            </a>
                            <span class="sale-tag">35%<br>
                                    <i>Off</i>
                                </span>
                            </div>
                        <div class="info">
                            <a href="https://www.chodientu.vn/dien-thoai-di-dong/kinh-thuc-te-ao-3d-dung-cho-dien-thoai-vr-box-phien-ban-3-huong-hieu-hong-kong-electronics-170149032929" class="name">KÍNH THỰC TẾ ẢO 3D DÙNG CHO ĐIỆN THOẠI VR BOX (PHIÊN BẢN 3) hương hiệu: Hong Kong Electronics</a>
                            <div class="price">
                                <span>195.000đ</span>
                                <span class="old-price">300.000đ</span>
                                </div>
                        </div>
                    </div></div><div class="owl-item" style="width: 288px; margin-right: 0px;"><div class="item">
                        <div class="thumb">
                            <a href="https://www.chodientu.vn/phich-nuoc-binh-giu-nhiet/binh-giu-nhiet-phong-cach-the-thao-500ml-185311624703">
                                <img style="width: 258px; height: 258px" src="https://chodientu.r.worldssl.net/images/2016/01/11/item/01/52/4/thumb_TB1G6H7KFXXXXXoXVXXXXXXXXXX___0-item_pic.jpg" alt="" title="">
                            </a>
                            <span class="sale-tag">31%<br>
                                    <i>Off</i>
                                </span>
                            </div>
                        <div class="info">
                            <a href="https://www.chodientu.vn/phich-nuoc-binh-giu-nhiet/binh-giu-nhiet-phong-cach-the-thao-500ml-185311624703" class="name">Bình giữ nhiệt phong cách thể thao 500ml </a>
                            <div class="price">
                                <span>159.000đ</span>
                                <span class="old-price">229.000đ</span>
                                </div>
                        </div>
                    </div></div><div class="owl-item" style="width: 288px; margin-right: 0px;"><div class="item">
                        <div class="thumb">
                            <a href="https://www.chodientu.vn/dien-thoai-di-dong/sony-z1-c6902-433568725838">
                                <img style="width: 258px; height: 258px" src="https://chodientu.r.worldssl.net/images/2016/06/22/item/09/29/7/thumb_1464518581959_2814.jpg" alt="" title="">
                            </a>
                            </div>
                        <div class="info">
                            <a href="https://www.chodientu.vn/dien-thoai-di-dong/sony-z1-c6902-433568725838" class="name">Sony Z1 C6902</a>
                            <div class="price">
                                <span>2.750.000đ</span>
                                </div>
                        </div>
                    </div></div><div class="owl-item" style="width: 288px; margin-right: 0px;"><div class="item">
                        <div class="thumb">
                            <a href="https://www.chodientu.vn/loa-mini/loa-bluetooth-bose-mini-818507813426">
                                <img style="width: 258px; height: 258px" src="https://chodientu.r.worldssl.net/images/2016/06/19/item/10/49/6/thumb_1466333289109.jpeg" alt="" title="">
                            </a>
                            <span class="sale-tag">36%<br>
                                    <i>Off</i>
                                </span>
                            </div>
                        <div class="info">
                            <a href="https://www.chodientu.vn/loa-mini/loa-bluetooth-bose-mini-818507813426" class="name">LOA BLUETOOTH BOSE MINI</a>
                            <div class="price">
                                <span>225.000đ</span>
                                <span class="old-price">350.000đ</span>
                                </div>
                        </div>
                    </div></div><div class="owl-item active" style="width: 288px; margin-right: 0px;"><div class="item">
                        <div class="thumb">
                            <a href="https://www.chodientu.vn/son-moi-618374322854/son-bbia-last-lipstick-vo-xanh-862262996269">
                                <img style="width: 258px; height: 258px" src="https://chodientu.r.worldssl.net/images/2016/06/23/item/04/35/3/thumb_son-li-bbia-last-lipstick-vo-xanh-1m4G3-04381f_simg_422f2e_1079-1079-0-0_cropf.jpg" alt="" title="">
                            </a>
                            <span class="sale-tag">46%<br>
                                    <i>Off</i>
                                </span>
                            </div>
                        <div class="info">
                            <a href="https://www.chodientu.vn/son-moi-618374322854/son-bbia-last-lipstick-vo-xanh-862262996269" class="name">Son BBIA Last Lipstick vỏ xanh</a>
                            <div class="price">
                                <span>90.000đ</span>
                                <span class="old-price">165.000đ</span>
                                </div>
                        </div>
                    </div></div><div class="owl-item cloned" style="width: 288px; margin-right: 0px;"><div class="item">
                        <div class="thumb">
                            <a href="https://www.chodientu.vn/dien-thoai-di-dong/kinh-thuc-te-ao-3d-dung-cho-dien-thoai-vr-box-phien-ban-3-huong-hieu-hong-kong-electronics-170149032929">
                                <img style="width: 258px; height: 258px" src="https://chodientu.r.worldssl.net/images/2016/06/22/item/05/11/9/thumb_HTB1yW_1JVXXXXaQXXXXq6xXFXXX8_281_29.jpg" alt="" title="">
                            </a>
                            <span class="sale-tag">35%<br>
                                    <i>Off</i>
                                </span>
                            </div>
                        <div class="info">
                            <a href="https://www.chodientu.vn/dien-thoai-di-dong/kinh-thuc-te-ao-3d-dung-cho-dien-thoai-vr-box-phien-ban-3-huong-hieu-hong-kong-electronics-170149032929" class="name">KÍNH THỰC TẾ ẢO 3D DÙNG CHO ĐIỆN THOẠI VR BOX (PHIÊN BẢN 3) hương hiệu: Hong Kong Electronics</a>
                            <div class="price">
                                <span>195.000đ</span>
                                <span class="old-price">300.000đ</span>
                                </div>
                        </div>
                    </div></div><div class="owl-item cloned" style="width: 288px; margin-right: 0px;"><div class="item">
                        <div class="thumb">
                            <a href="https://www.chodientu.vn/phich-nuoc-binh-giu-nhiet/binh-giu-nhiet-phong-cach-the-thao-500ml-185311624703">
                                <img style="width: 258px; height: 258px" src="https://chodientu.r.worldssl.net/images/2016/01/11/item/01/52/4/thumb_TB1G6H7KFXXXXXoXVXXXXXXXXXX___0-item_pic.jpg" alt="" title="">
                            </a>
                            <span class="sale-tag">31%<br>
                                    <i>Off</i>
                                </span>
                            </div>
                        <div class="info">
                            <a href="https://www.chodientu.vn/phich-nuoc-binh-giu-nhiet/binh-giu-nhiet-phong-cach-the-thao-500ml-185311624703" class="name">Bình giữ nhiệt phong cách thể thao 500ml </a>
                            <div class="price">
                                <span>159.000đ</span>
                                <span class="old-price">229.000đ</span>
                                </div>
                        </div>
                    </div></div></div></div><div class="owl-controls"><div class="owl-nav"><div class="owl-prev" style="display: none;">prev</div><div class="owl-next" style="display: none;">next</div></div><div class="owl-dots" style=""><div class="owl-dot"><span></span></div><div class="owl-dot"><span></span></div><div class="owl-dot"><span></span></div><div class="owl-dot"><span></span></div><div class="owl-dot active"><span></span></div></div></div></div>
<!--            <div class="view-all">
                <button type="button" class="btn btn-default">View All Deals</button>
            </div>-->
        </div>
    </div>
</div>
</div>
</div></div>
        <footer class="shop2-footer">
    <div class="top">
        <div class="container">
            <div class="row">
                <div class="col-md-3">
                    <div class="title">DANH MỤC</div>
                    <ul class="list">
                        <li><a href="https://www.chodientu.vn">Trang chủ ChợĐiệnTử</a></li>
                        <li><a href="https://www.chodientu.vn/shop/BanHangGiaRe">Trang chủ SHOP</a></li>
                        <li><a href="https://www.chodientu.vn/shop/BanHangGiaRe/browse">Sản phẩm</a></li>
                        <li><a href="https://www.chodientu.vn/shop/BanHangGiaRe/khuyen-mai">Khuyến mãi</a></li>
                        <li><a href="https://www.chodientu.vn/shop/BanHangGiaRe/tin-tuc">Tin tức</a></li>
                        <li><a href="https://www.chodientu.vn/shop/BanHangGiaRe/lien-he">Liên hệ</a></li>
                    </ul>
                </div>
                <div class="col-md-3">
                    <div class="title">TÀI KHOẢN CỦA BẠN</div>
                    <ul class="list">
                        <li>Tài khoản của tôi</li>
                        <li>Quan tâm của</li>
                        <li>Thông tin giỏ hàng</li>
                        <li>Kiểm tra hành trình đơn hàng</li>
                    </ul>
                </div>
                <div class="col-md-3">
                    
                </div>
                <div class="col-md-3">
                    <div class="title">THÔNG TIN SHOP</div>
                    <ul class="contact">
                        <li><i class="fa fa-map-marker"></i> 17/1P Nguyễn Thị Tần, P2, Q8, HCM</li>
                        <li><i class="fa fa-phone"></i> 01234917936</li>
                        <li><i class="fa fa-envelope"></i> linhkiengiare1234@gmail.com</li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
</footer>
<!-- alias-outer -->
        <div class="loading-fast"></div>
        <div class="bg-ovelay"></div>
        <div class="smart-cart">
            <div class="sc-inner">
                <div class="sc-header">
                    <div class="sc-title">
                        <span class="sc-iconcart">0</span> Giỏ hàng của tôi
                    </div>
                </div>
                <!-- sc-header -->
                <div class="sc-content htmlViewCart">
                    <!--</div>-->
                </div>
            </div>
        </div>
        <!-- smart-cart -->

        <!-- Core JavaScript -->
        <script>
            $(document).ready(function () {
                order.countCart();
            });
        </script>
        <script>
            var baseUrl = 'https://www.chodientu.vn';
            var staticUrl = 'https://www.chodientu.vn/static';
            shopCategories=[];shop={"userId":"44364359114","alias":"BanHangGiaRe","title":"BanHangGiaRe","address":"17/1P Nguyễn Thị Tần, P2, Q8, HCM","lng":0.0,"lat":0.0,"active":true,"version":"VER2","step":"3","phone":"01234917936","email":"linhkiengiare1234@gmail.com","cityId":"537ef470e4b0d29973e039c8","districtId":"537ef470e4b0d29973e039da","viewCount":0,"createTime":1466330932050,"reputationPoint":0.0,"activityPoint":0.0};shopv2.init();
        </script>
    
<script type="text/javascript">window.NREUM||(NREUM={});NREUM.info={"errorBeacon":"bam.nr-data.net","licenseKey":"a8948bf81e","agent":"","beacon":"bam.nr-data.net","applicationTime":512,"applicationID":"9036146","transactionName":"NF1TZ0RTDURRUERZDA0XYkNEWw1Qc1xeRBEMVF1WRB0QX19DH0sCD1FQQEsSS3B1Zxk=","queueTime":0}</script>

</body>
</html>